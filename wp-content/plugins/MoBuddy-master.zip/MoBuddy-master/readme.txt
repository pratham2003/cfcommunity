=== MoBuddy ===
Contributors: johnjamesjacoby, buddyboss, 10up
Tags: mobile, buddypress, bbpress
Requires at least: 3.0
Tested up to: 4.0
Stable tag: 0.1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A great mobile experience for your BuddyPress powered site.

== Description ==

MoBuddy wraps your beautiful WordPress theme in a great mobile experience.

== Installation ==

= From your WordPress dashboard =

1. Visit 'Plugins > Add New'
2. Search for 'MoBuddy'
3. Activate MoBuddy from your Plugins page.
4a. If you're using a WordPress core theme, you're already done!
4b. If you're using a custom theme, visit Appearance > MoBuddy and configure the one and only option.

= From WordPress.org =

1. Download MoBuddy.
2. Upload the 'mobuddy' directory to your '/wp-content/plugins/' directory, using your favorite method (ftp, sftp, scp, etc...)
3. Activate MoBuddy from your Plugins page.
4a. If you're using a WordPress core theme, you're already done!
4b. If you're using a custom theme, visit Appearance > MoBuddy and configure the one and only option.

== Changelog ==

= 0.1.0 =
* Initial release.