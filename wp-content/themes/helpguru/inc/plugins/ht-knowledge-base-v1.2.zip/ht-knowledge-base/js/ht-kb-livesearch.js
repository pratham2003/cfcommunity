
	jQuery(document).ready(function() {
		jQuery('#ht-kb-search #s').liveSearch({url: framework.liveSearchUrl});
	});
	