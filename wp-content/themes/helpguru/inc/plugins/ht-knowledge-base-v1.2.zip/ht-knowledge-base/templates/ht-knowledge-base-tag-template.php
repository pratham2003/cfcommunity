<?php
/**
 * The template for displaying heroic knowledgebase tags
 */

@include_once('ht-knowledge-base-category-template.php');